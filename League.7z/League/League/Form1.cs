﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using System.Diagnostics;

namespace League
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Search();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Exits application
            System.Windows.Forms.Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Clears the textbox
            textBox.Clear();
        }

        private void Player0Button_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(player0Label.Text);
        }

        private void Player1Button_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(player1Label.Text);
        }

        private void Player2Button_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(player2Label.Text);
        }

        private void Player3Button_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(player3Label.Text);
        }

        private void Search()
        {
            int playerNum = 0;

            foreach (var v in textBox.Lines)
            {
                string[] line = v.Split(' ');

                int numWords = line.Count();

                //removes excess leauge words (joined the lobby)
                line[numWords - 1] = "";
                line[numWords - 2] = "";
                line[numWords - 3] = "";

                //Converts the array back to string
                string name = String.Join(" ", line);

                if (!name.Contains("BaZerkary"))
                {
                    player0Button.Enabled = false;
                    player1Button.Enabled = false;
                    player2Button.Enabled = false;
                    player3Button.Enabled = false;


                    //opens op.gg in a browser
                    Process.Start("chrome", @"http://op.gg/");
                    Clipboard.SetText(name);

                    //waits for browser to open then searched for the user
                    Thread.Sleep(5000);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{ENTER}");

                    switch (playerNum)
                    {
                        case 0:
                            player0Label.Text = name;
                            break;
                        case 1:
                            player1Label.Text = name;
                            break;
                        case 2:
                            player2Label.Text = name;
                            break;
                        case 3:
                            player3Label.Text = name;
                            break;
                    }

                    ++playerNum;

                    player0Button.Enabled = true;
                    player1Button.Enabled = true;
                    player2Button.Enabled = true;
                    player3Button.Enabled = true;
                }
            }
        }
    }
}
