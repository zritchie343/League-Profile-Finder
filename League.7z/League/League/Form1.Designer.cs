﻿namespace League
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.textBox = new System.Windows.Forms.RichTextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.player0Label = new System.Windows.Forms.Label();
            this.player1Label = new System.Windows.Forms.Label();
            this.player2Label = new System.Windows.Forms.Label();
            this.player3Label = new System.Windows.Forms.Label();
            this.player0Button = new System.Windows.Forms.Button();
            this.player1Button = new System.Windows.Forms.Button();
            this.player2Button = new System.Windows.Forms.Button();
            this.player3Button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 124);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Run";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox
            // 
            this.textBox.Location = new System.Drawing.Point(12, 12);
            this.textBox.Name = "textBox";
            this.textBox.Size = new System.Drawing.Size(187, 104);
            this.textBox.TabIndex = 1;
            this.textBox.Text = "";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(12, 153);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "Clear";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(12, 182);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 3;
            this.button3.Text = "Exit";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // player0Label
            // 
            this.player0Label.AutoSize = true;
            this.player0Label.Location = new System.Drawing.Point(212, 17);
            this.player0Label.Name = "player0Label";
            this.player0Label.Size = new System.Drawing.Size(45, 13);
            this.player0Label.TabIndex = 6;
            this.player0Label.Text = "Player 1";
            // 
            // player1Label
            // 
            this.player1Label.AutoSize = true;
            this.player1Label.Location = new System.Drawing.Point(212, 45);
            this.player1Label.Name = "player1Label";
            this.player1Label.Size = new System.Drawing.Size(45, 13);
            this.player1Label.TabIndex = 7;
            this.player1Label.Text = "Player 2";
            // 
            // player2Label
            // 
            this.player2Label.AutoSize = true;
            this.player2Label.Location = new System.Drawing.Point(212, 76);
            this.player2Label.Name = "player2Label";
            this.player2Label.Size = new System.Drawing.Size(45, 13);
            this.player2Label.TabIndex = 8;
            this.player2Label.Text = "Player 3";
            // 
            // player3Label
            // 
            this.player3Label.AutoSize = true;
            this.player3Label.Location = new System.Drawing.Point(212, 105);
            this.player3Label.Name = "player3Label";
            this.player3Label.Size = new System.Drawing.Size(45, 13);
            this.player3Label.TabIndex = 9;
            this.player3Label.Text = "Player 4";
            // 
            // player0Button
            // 
            this.player0Button.Location = new System.Drawing.Point(263, 12);
            this.player0Button.Name = "player0Button";
            this.player0Button.Size = new System.Drawing.Size(75, 23);
            this.player0Button.TabIndex = 10;
            this.player0Button.Text = "Copy";
            this.player0Button.UseVisualStyleBackColor = true;
            this.player0Button.Click += new System.EventHandler(this.Player0Button_Click);
            // 
            // player1Button
            // 
            this.player1Button.Location = new System.Drawing.Point(263, 40);
            this.player1Button.Name = "player1Button";
            this.player1Button.Size = new System.Drawing.Size(75, 23);
            this.player1Button.TabIndex = 11;
            this.player1Button.Text = "Copy";
            this.player1Button.UseVisualStyleBackColor = true;
            this.player1Button.Click += new System.EventHandler(this.Player1Button_Click);
            // 
            // player2Button
            // 
            this.player2Button.Location = new System.Drawing.Point(263, 71);
            this.player2Button.Name = "player2Button";
            this.player2Button.Size = new System.Drawing.Size(75, 23);
            this.player2Button.TabIndex = 12;
            this.player2Button.Text = "Copy";
            this.player2Button.UseVisualStyleBackColor = true;
            this.player2Button.Click += new System.EventHandler(this.Player2Button_Click);
            // 
            // player3Button
            // 
            this.player3Button.Location = new System.Drawing.Point(263, 100);
            this.player3Button.Name = "player3Button";
            this.player3Button.Size = new System.Drawing.Size(75, 23);
            this.player3Button.TabIndex = 13;
            this.player3Button.Text = "Copy";
            this.player3Button.UseVisualStyleBackColor = true;
            this.player3Button.Click += new System.EventHandler(this.Player3Button_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(353, 220);
            this.Controls.Add(this.player3Button);
            this.Controls.Add(this.player2Button);
            this.Controls.Add(this.player1Button);
            this.Controls.Add(this.player0Button);
            this.Controls.Add(this.player3Label);
            this.Controls.Add(this.player2Label);
            this.Controls.Add(this.player1Label);
            this.Controls.Add(this.player0Label);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "League Profile";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RichTextBox textBox;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label player0Label;
        private System.Windows.Forms.Label player1Label;
        private System.Windows.Forms.Label player2Label;
        private System.Windows.Forms.Label player3Label;
        private System.Windows.Forms.Button player0Button;
        private System.Windows.Forms.Button player1Button;
        private System.Windows.Forms.Button player2Button;
        private System.Windows.Forms.Button player3Button;
    }
}

